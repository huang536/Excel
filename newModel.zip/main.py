import sys
import os
import platform
import threading
import openpyxl
from openpyxl import Workbook
import pandas as pd
from PySide6.QtWidgets import QApplication, QMainWindow, QWidgetAction,QTableWidget,QTableView, QWidget, QTabWidget, QTableWidgetItem,QProgressBar,QLineEdit, QFileDialog
from PySide6.QtCore import QThread, Signal

import time

from PySide6.QtGui import QColor, QStandardItem, QStandardItemModel,QIcon


# IMPORT / GUI AND MODULES AND WIDGETS
# ///////////////////////////////////////////////////////////////

from modules import *

os.environ["QT_FONT_DPI"] = "96" # FIX Problem for High DPI and Scale above 100%
from PySide6 import QtCore, QtGui, QtWidgets

widgets = None



class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # SET AS GLOBAL WIDGETS
        # ///////////////////////////////////////////////////////////////
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        global widgets
        widgets = self.ui





        # APP NAME
        # ///////////////////////////////////////////////////////////////
        title = "起个名"
        # APPLY TEXTS
        self.setWindowTitle(title)

######菜单#####
     ###顶部TabWidget
        widgets.file_act_2.triggered.connect(self.buttonClick_MainMenu)
        widgets.direc_act_2.triggered.connect(self.buttonClick_MainMenu)
        widgets.data_act.triggered.connect(self.load_excel_file)
        widgets.excel_act.triggered.connect(self.excel_action_connect)
        # 更新
        widgets.update_act.triggered.connect(self.update_btn_checked)
        # 增加行,列
        widgets.in_rows_act_2.triggered.connect(self.on_add_rows_activated)
        widgets.in_columns_act.triggered.connect(self.on_add_colums_activated)
        # 删除
        widgets.del_rows_act_2.triggered.connect(self.delete_rows)
        widgets.del_columns_act.triggered.connect(self.delete_columns)
        #保存
        widgets.save_act.triggered.connect(self.save_to_xlsx)
        #筛选
        widgets.select_act.triggered.connect(self.set_button_overlay)


#####文件列表#####
        # 文件传入
        # 点击工程栏文件，记录file_path
        self.file_path = None
        widgets.fileTree.currentItemChanged.connect(self.on_tree_item_changed)

##### main menu #####
        ### 筛选 ###
        print(self.file_path)



##################################
##########def#####################

#####顶部Menu#####
    ##open_tab
    def buttonClick_MainMenu(self):
        btn = self.sender()
        btnName = btn.objectName()

        # Open File
        if btnName == "file_act_2":
            """
            弹出窗口选择导入文件或文件夹，并显示在工程栏
            """
            # 弹窗选择文件或文件夹
            file_path, _ = QFileDialog.getOpenFileName(self, "选择文件", "", "All Files (*);;Text Files (*.txt)")

            if not file_path:
                # 如果没有选择文件，则不执行下面的操作
                return
            # 获取文件或文件夹的名称和路径
            file_name = os.path.basename(file_path)

            # 判断是文件还是文件夹
            if os.path.isfile(file_path):
                # 添加一个Top Level Item，表示导入的文件
                top_item = QTreeWidgetItem(widgets.fileTree, [file_name])
                top_item.setData(0, Qt.UserRole, file_path)
                # 标记为文件类型
                top_item.setData(0, Qt.UserRole + 1, "FILE")
                # 初始选中
                widgets.fileTree.setCurrentItem(top_item)
                widgets.label_file_path.setText(file_path)

        if btnName == "direc_act_2":

            # 获取文件夹路径
            folder_path = QFileDialog.getExistingDirectory(None, "选择文件夹", "./")

            if not folder_path:
                # 如果没有选择文件夹，则不执行下面的操作
                return

            dir_name = os.path.basename(folder_path)
            # tree_file = self.ui.fileTree
            top_item = QTreeWidgetItem(widgets.fileTree, [dir_name])
            top_item.setData(0, Qt.UserRole + 1, "FOLDER")
            # 获取文件夹中所有的文件
            dir_iter = QDir(folder_path)
            dir_iter.setFilter(QDir.Files)
            dir_iter.setSorting(QDir.Name | QDir.IgnoreCase)
            files = dir_iter.entryInfoList()
            if not files:
                # 如果文件夹中没有文件，则不执行下面的操作
                return
            # 设置顶级项的文本为文件夹名称
            top_item.setText(0, os.path.basename(folder_path))
            # 将文件夹的路径设置为顶级项的数据
            top_item.setData(0, Qt.UserRole, folder_path)
            # 标记为文件夹类型
            top_item.setData(0, Qt.UserRole + 1, "FOLDER")
            # 循环遍历文件并添加到文件树对象中
            for file_info in files:
                item = QTreeWidgetItem()
                item.setText(0, file_info.fileName())
                item.setData(0, Qt.UserRole, file_info.absoluteFilePath())
                item.setData(0, Qt.UserRole + 1, "FILE")
                top_item.addChild(item)
            # 父项设置为具有子项的项以显示展开符号
            top_item.setExpanded(True)
            widgets.label_file_path.setText(folder_path)

#####工程列表#####
# 鼠标选中记录file_path
    def on_tree_item_changed(self, item, column):
        # 获取双击的项的数据
        self.file_path = item.data(0, Qt.UserRole)
        print(self.file_path)

###### Main Page #####
    ### 样本浏览 ###
    ##EXCEL##
    def excel_action_connect(self):
        filepath = self.file_path
        os.startfile(filepath)
    def load_excel_file(self):
        # 获取文件路径
        filepath = self.file_path

        if filepath:
            # 读取 Excel 文件
            excel_file = pd.ExcelFile(filepath, engine='openpyxl')
            sheet_count = len(excel_file.sheet_names)
            start_time = time.time()

            # 创建内部的 TabWidget
            self.inner_tab_widget = QTabWidget(self)

            # 遍历每个 sheet，并将其添加到内部的 TabWidget 中
            for i, sheet_name in enumerate(excel_file.sheet_names):
                df = excel_file.parse(sheet_name, header=None)  # 不读取表头
                self.model = QStandardItemModel()

                for column in df:
                    if pd.api.types.is_categorical_dtype(df[column]):
                        color_series = pd.Series(df[column].cat.codes.astype(float)).map(
                            lambda x: QColor(x * 256, x * 256, x * 256))
                        self.model.appendColumn([QStandardItem(color.to_string()) for color in color_series.tolist()])
                    else:
                        self.model.appendColumn([QStandardItem(str(entry)) for entry in df[column].tolist()])

                # 获取当前选项卡上的控件
                control = self.inner_tab_widget.widget(i)
                # 判断控件是否为 QTableView 类型
                if isinstance(control, QTableView):
                    control.setModel(self.model)  # 将数据模型设置为 model
                else:
                    # 在当前选项卡上创建一个 QTableView 及其布局
                    self.table_view = QTableView(self.inner_tab_widget.tabBar())
                    self.table_view.setModel(self.model)  # 将数据模型设置为 model
                    self.inner_tab_widget.addTab(self.table_view, sheet_name)  # 将 TableView 添加到选项卡上




            # 让表格显示表头，并让列宽度自适应窗口宽度
            self.inner_tab_widget.currentWidget().horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

            #设置列宽自适应单元格内容
            header = self.table_view.horizontalHeader() #获取当前选项卡上的控件 table_view 的 horizontalHeader() 对象，这是一个 QHeaderView 类型的对象，用于管理表头。
            header.setSectionResizeMode(QHeaderView.ResizeToContents) #利用 ResizeToContents 参数来自适应单元格内容，将表格列的宽度设置为能够显示内容的最小宽度。
            header.setSectionResizeMode(QHeaderView.Interactive)
            header.sectionResized.connect(lambda lidx, old_sz, new_sz: self.adjust_column_widths(lidx, old_sz, new_sz,self.table_view))

            # 将子类加入父类
            self.file_name = os.path.basename(self.file_path)
            widgets.data_tabW.addTab(self.inner_tab_widget, self.file_name)
            #设置TabsClosable
            widgets.data_tabW.tabCloseRequested.connect(self.closeTab)

            # 获取选中列索引
            self.table_view.clicked.connect(self.on_tableview_clicked)

    #筛选
    def set_button_overlay(self):
        for column in range(self.model.columnCount()):


            self.button = QMenu(self.table_view)
            self.button.setTitle("∨")

            # 设置按钮尺寸
            self.button.setFixedSize(QSize(15,15))

            # 设置按钮位置
            option = QStyleOptionViewItem()
            option.rect = self.table_view.visualRect(self.model.index(0, column))
            option.state |= QStyle.State_MouseOver

            sub_action1 = QAction("Sub Item 1", self)
            sub_action2 = QAction("Sub Item 2", self)

            self.button.addAction(sub_action1)
            self.button.addAction(sub_action2)
            self.button.setWindowFlags(self.button.windowFlags() | Qt.WindowStaysOnTopHint)
            self.button.move(option.rect.right() - self.button.width(), option.rect.bottom() - self.button.height())





            # 绘制按钮

            self.button.show()
            # button..connect(self.button_clicked)  # 连接点击事件
            # 将按钮设置为单元格的小部件
            self.table_view.setIndexWidget(self.model.index(0, column), self.button)


    def button_clicked(self):
        # 获取点击的按钮
        self.button = self.sender()
        # 获取按钮所在的单元格位置
        index = self.table_view.indexAt(self.button.pos())
        #列索引
        selected_column = index.column()
        # 获取单元格的数据
        data = self.model.data(index, Qt.DisplayRole)

        # 输出单元格的数据
        print(f"点击了按钮，单元格数据为：{data}，索引为：{selected_column}")

        self.widget = QLabel("Widget")
        self.widget_action = QWidgetAction(self)
        self.widget_action.setDefaultWidget(self.widget)

        self.menu = QMenu(self.button)
        self.menu.addAction(self.widget_action)
        self.menu.setWindowFlags(self.menu.windowFlags() | Qt.WindowStaysOnTopHint) #置于顶层

    def show_menu(self):
        position = self.button.mapToGlobal(self.button.rect().bottomLeft())
        self.menu.popup(position)

    # 设置列宽自适应单元格内容
    def adjust_column_widths(self, logicalIndex, oldSize, newSize, table_view):
        tableview = self.table_view
        if newSize > oldSize:
            tableview.horizontalHeader().setSectionResizeMode(
                logicalIndex, QHeaderView.ResizeToContents)
    # 设置closetab
    def closeTab(self, currentIndex):
        widgets.data_tabW.removeTab(currentIndex)

    ##获取列索引
    def on_tableview_clicked(self, index):
        """TableView的单击事件"""
        self.selected_column = index.column()

        # 获取选中列的首行单元格内容

        item = self.model.item(0, self.selected_column)
        if item is not None:
            self.cell_value = item.text()

            print("First cell value in selected column: {}".format(self.cell_value))

    # 更新
    def update_btn_checked(self):
        self.table_view.setModel(self.model)
    # 增加行、列
    def on_add_rows_activated(self, index):

        # 获取当前选择的单元格的索引
        index = self.table_view.selectedIndexes()
        if index:
            # 获取当前选择的单元格所在的行号
            row = index[0].row()
            # 创建一个新的空行
            new_row_items = [QStandardItem("") for _ in range(self.model.columnCount())]
            # 在表格中插入该行
            self.model.insertRow(row, new_row_items)
            # 重新设定选中的单元格
            new_index = self.model.index(row, 0)
            self.table_view.setCurrentIndex(new_index)
    def on_add_colums_activated(self, index):
        # 获取当前单元格的索引，当前选择的行
        current_index = self.table_view.currentIndex()
        # 获取所选行的行号
        row = current_index.row()
        # 获取所选行的列数
        col = current_index.column()
        # 如果所选列不是最后一列，则在其右侧插入一列
        if col < self.model.columnCount() - 1:
            # 在表格模型中插入新列
            self.model.insertColumn(col + 1)
        else:
            # 如果所选列是最后一列，则在其右侧添加一列
            self.model.insertColumn(self.model.columnCount())
    # 删除行、列
    def delete_rows(self, index):
        row = self.table_view.currentIndex().row()
        column = self.table_view.currentIndex().column()
        self.model.removeRow(row)
    def delete_columns(self,index):
        row = self.table_view.currentIndex().row()
        column = self.table_view.currentIndex().column()
        self.model.removeColumn(column)
    # 保存
    def save_to_xlsx(self):
        if not widgets.data_tabW.count() > 0:
            # 如果表格没有数据，则显示警告对话框
            message_box = QMessageBox()
            message_box.critical(self, 'Error', "数据未读入！")
            return
        file_path, _ = QFileDialog.getSaveFileName(self, "文件保存", '', 'Excel Files (*.xlsx)')
        if file_path:
            try:
                workbook = Workbook()
                sheet = workbook.active
                # 将表格数据逐个写入到 Excel 文件中
                for row in range(self.model.rowCount()):
                    for col in range(self.model.columnCount()):
                        index = self.model.index(row, col)
                        data = str(self.model.data(index))
                        sheet.cell(row=row + 1, column=col + 1, value=data)
                workbook.save(file_path)
                message_box = QMessageBox()
                message_box.information(self, 'Success', "保存成功！")
            except Exception as e:
                message_box = QMessageBox()
                message_box.critical(self, 'Error', str(e))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("icon.ico"))
    window = MainWindow()
    window.show()

    sys.exit(app.exec_())